#!/bin/bash
#function for reading arg, checking if arg is a directory, 

arg=$1

direct_select()
{
if [[ -d "$arg" ]]; 
then direct_var=`(ls $arg)`
  echo $direct_var | sed 's/[A-Z]/&&&/g'
else
  echo "Not a directory" > printcap3_error.log;
fi
}

direct_select